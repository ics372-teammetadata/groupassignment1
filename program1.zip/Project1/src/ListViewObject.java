
public class ListViewObject 
{
	// purposely empty.
	// only used so artist, author, CD, etc. can all go in single listView
}
